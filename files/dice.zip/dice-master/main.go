package main

import (
  "fmt"
)

func main() {
  //Print introduction to game of dice
  fmt.Print("Welcome to Delman's Dice Game!")
	fmt.Print("\n------------------------------")
	fmt.Print("\nEnter below to roll the dice.")
  //Call choice of dice function
  diceChoice() 
}