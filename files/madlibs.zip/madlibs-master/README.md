# Mulligan Mad Libs
Mulligan Mad Libs is a Python application that let's the user choose the story.

## Usage
Open madlib.exe inside \dist. Double clicking file should open CLI for user to input numeric correlation to story choice, and then nouns, verbs, and much more to fill in for the stories.
